public interface MethodRequest {
    public boolean guard();
    public void call();
}
